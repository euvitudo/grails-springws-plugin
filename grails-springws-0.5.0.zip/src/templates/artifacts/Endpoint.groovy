@artifact.package@

class @artifact.name@ {
	
	def static namespace = "http://yourcompany.com/schemas" 
	
	def invoke = { request, response ->
        // TODO Deal with the incoming XML document here.
        null
    }
}